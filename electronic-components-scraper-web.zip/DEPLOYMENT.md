# 部署指南

本指南将详细介绍如何将贸泽电子元器件价格爬虫Web应用程序部署到不同的免费平台。

## 目录

1. [Railway部署](#railway部署)
2. [Vercel部署](#vercel部署)
3. [Render部署](#render部署)
4. [本地开发](#本地开发)

## Railway部署

Railway是一个现代化的云部署平台，提供简单易用的部署体验。

### 步骤1: 注册Railway账户

1. 访问 [Railway官网](https://railway.app/)
2. 点击"Start a New Project"
3. 选择注册方式（推荐使用GitHub账户注册）

### 步骤2: 部署应用程序

#### 方法一: 通过GitHub部署（推荐）

1. Fork本项目到你的GitHub账户
2. 在Railway控制台点击"New Project"
3. 选择"Deploy from GitHub repo"
4. 选择你fork的项目仓库
5. Railway会自动检测这是Python应用并配置环境
6. 点击"Deploy"开始部署

#### 方法二: 直接上传代码

1. 在Railway控制台点击"New Project"
2. 选择"Deploy from Source Code"
3. 上传项目代码压缩包
4. Railway会自动配置环境并部署

### 步骤3: 配置环境变量

1. 在Railway项目页面点击"Settings"
2. 在"Variables"部分添加环境变量（如果需要）
3. Railway会自动从代码中检测依赖并安装

### 步骤4: 访问应用

1. 部署完成后，Railway会提供一个公共URL
2. 点击URL即可访问你的应用

## Vercel部署

Vercel主要用于前端部署，但也支持Python后端应用。

### 步骤1: 注册Vercel账户

1. 访问 [Vercel官网](https://vercel.com/)
2. 点击"Sign Up"
3. 选择注册方式（推荐使用GitHub账户注册）

### 步骤2: 安装Vercel CLI

```bash
npm install -g vercel
```

### 步骤3: 部署应用

1. 在项目根目录打开终端
2. 登录Vercel:
   ```bash
   vercel login
   ```
3. 部署到生产环境:
   ```bash
   vercel --prod
   ```
4. 按照提示完成部署

### 步骤4: 配置项目

1. 当提示"Set up and deploy"时，选择"Yes"
2. 当提示"Which scope"时，选择你的账户
3. 当提示"Link to existing project"时，选择"No"
4. 当提示"Project name"时，输入项目名称
5. 当提示"Root directory"时，输入"."
6. 当提示"Override settings"时，选择"No"

## Render部署

Render是另一个优秀的Heroku替代品。

### 步骤1: 注册Render账户

1. 访问 [Render官网](https://render.com/)
2. 点击"Sign Up"
3. 选择注册方式

### 步骤2: 创建Web Service

1. 点击"New" -> "Web Service"
2. 连接你的GitHub账户
3. 选择项目仓库
4. 配置以下设置:
   - Name: 输入应用名称
   - Region: 选择离你最近的区域
   - Branch: 选择主分支
   - Root Directory: 保持为空
   - Environment: 选择"Python 3"
   - Build Command: `pip install -r requirements.txt`
   - Start Command: `python main.py`

### 步骤3: 部署

1. 点击"Create Web Service"
2. Render会自动开始部署
3. 部署完成后会提供公共URL

## 本地开发

### 环境要求

- Python 3.7或更高版本
- pip包管理器

### 安装依赖

```bash
pip install -r requirements.txt
```

### 启动应用

```bash
python main.py
```

### 访问应用

在浏览器中访问 `http://localhost:5000`

## 故障排除

### 常见问题

1. **部署失败**: 检查依赖是否正确安装
2. **API请求失败**: 确保提供了正确的Mouser API密钥
3. **文件上传失败**: 检查文件格式是否正确

### 日志查看

- Railway: 在项目页面点击"Logs"查看实时日志
- Vercel: 使用`vercel logs`命令查看日志
- Render: 在项目页面点击"Logs"查看日志

## 性能优化建议

1. **API密钥管理**: 建议使用环境变量存储API密钥
2. **缓存机制**: 可以添加Redis缓存来提高查询速度
3. **数据库**: 对于大量数据，建议使用数据库存储查询结果
4. **CDN**: 使用CDN加速静态资源加载

## 安全建议

1. **API密钥保护**: 不要在代码中硬编码API密钥
2. **输入验证**: 对用户输入进行严格验证
3. **速率限制**: 实施适当的速率限制防止滥用
4. **HTTPS**: 确保所有通信都通过HTTPS进行