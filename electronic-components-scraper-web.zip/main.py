#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
贸泽电子元器件价格爬虫主程序
"""

import sys
import os

# 添加项目路径到Python路径
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from app import app

if __name__ == "__main__":
    app.run(host='0.0.0.0', port=int(os.environ.get('PORT', 5000)), debug=False)