from flask import Flask, render_template, request, jsonify, send_file
import os
import sys
import pandas as pd
from io import BytesIO
from mouser_api import MouserAPI
from excel_handler import ExcelHandler

# 添加项目路径到Python路径
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

app = Flask(__name__)

# 初始化处理器
excel_handler = ExcelHandler()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/search', methods=['POST'])
def search_components():
    try:
        # 获取表单数据
        api_key = request.form.get('api_key')
        single_component = request.form.get('single_component', '').strip()
        batch_components = request.form.get('batch_components', '').strip()
        file_data = request.files.get('file')
        
        # 验证API密钥
        if not api_key:
            return jsonify({'error': '请提供Mouser API密钥'}), 400
        
        # 初始化API
        mouser_api = MouserAPI()
        # 覆盖API密钥
        mouser_api.api_keys = [api_key]
        
        # 收集所有要搜索的元件型号
        components = []
        
        # 添加单个输入的元件
        if single_component:
            components.append(single_component)
        
        # 添加批量输入的元件
        if batch_components:
            batch_list = [line.strip() for line in batch_components.split('\n') if line.strip()]
            components.extend(batch_list)
        
        # 添加文件中的元件
        if file_data and file_data.filename:
            # 处理上传的文件
            filename = file_data.filename
            if filename.endswith('.xlsx'):
                # 保存临时文件
                temp_path = f"temp_{filename}"
                file_data.save(temp_path)
                file_components = excel_handler.read_components_from_excel(temp_path)
                os.remove(temp_path)  # 清理临时文件
            elif filename.endswith('.txt'):
                # 保存临时文件
                temp_path = f"temp_{filename}"
                file_data.save(temp_path)
                file_components = excel_handler.read_components_from_txt(temp_path)
                os.remove(temp_path)  # 清理临时文件
            else:
                return jsonify({'error': '不支持的文件格式，请使用.xlsx或.txt文件'}), 400
            components.extend(file_components)
        
        if not components:
            return jsonify({'error': '请至少输入一个元件型号'}), 400
        
        # 搜索元件
        results = []
        for component in components:
            try:
                # 搜索元件
                part_data = mouser_api.search_part(component)
                
                if part_data:
                    # 提取价格信息
                    price, quantity = mouser_api.extract_pricing_info(part_data)
                    
                    # 检查是否停产
                    is_discontinued = mouser_api.is_discontinued(part_data)
                    
                    # 获取替代型号
                    replacement_part = mouser_api.get_replacement_part(part_data)
                    
                    # 设置备注信息
                    if is_discontinued and price == 0:
                        remark = "已停产无价格"
                    elif is_discontinued:
                        remark = "已停产"
                    elif price == 0:
                        remark = "无价格信息"
                    else:
                        remark = ""
                    
                    result = {
                        "元件型号": component,
                        "搜索型号": component,
                        "产品名称": part_data.get("ManufacturerPartNumber", ""),
                        "品牌": part_data.get("Manufacturer", ""),
                        "价格": price,
                        "最大批次": quantity,
                        "库存": part_data.get("Availability", ""),
                        "是否停产": "是" if is_discontinued else "否",
                        "替代型号": replacement_part,
                        "备注": remark
                    }
                else:
                    # 尝试搜索相似型号
                    similar_part_data = mouser_api.search_similar_part(component)
                    if similar_part_data:
                        # 提取价格信息
                        price, quantity = mouser_api.extract_pricing_info(similar_part_data)
                        
                        # 检查是否停产
                        is_discontinued = mouser_api.is_discontinued(similar_part_data)
                        
                        # 获取替代型号
                        replacement_part = mouser_api.get_replacement_part(similar_part_data)
                        
                        # 设置备注信息
                        if is_discontinued and price == 0:
                            remark = "已停产无价格"
                        elif is_discontinued:
                            remark = "已停产"
                        elif price == 0:
                            remark = "无价格信息"
                        else:
                            remark = "相似型号爬取"
                        
                        result = {
                            "元件型号": component,
                            "搜索型号": similar_part_data.get("ManufacturerPartNumber", ""),
                            "产品名称": similar_part_data.get("ManufacturerPartNumber", ""),
                            "品牌": similar_part_data.get("Manufacturer", ""),
                            "价格": price,
                            "最大批次": quantity,
                            "库存": similar_part_data.get("Availability", ""),
                            "是否停产": "是" if is_discontinued else "否",
                            "替代型号": replacement_part,
                            "备注": remark
                        }
                    else:
                        result = {
                            "元件型号": component,
                            "搜索型号": "",
                            "产品名称": "",
                            "品牌": "",
                            "价格": 0,
                            "最大批次": 0,
                            "库存": "",
                            "是否停产": "否",
                            "替代型号": "",
                            "备注": "未找到"
                        }
                
                results.append(result)
                
            except Exception as e:
                error_result = {
                    "元件型号": component,
                    "搜索型号": "",
                    "产品名称": "",
                    "品牌": "",
                    "价格": 0,
                    "最大批次": 0,
                    "库存": "",
                    "是否停产": "否",
                    "替代型号": "",
                    "备注": f"错误: {str(e)}"
                }
                results.append(error_result)
        
        return jsonify({'results': results})
        
    except Exception as e:
        return jsonify({'error': f'处理请求时发生错误: {str(e)}'}), 500

@app.route('/export', methods=['POST'])
def export_results():
    try:
        # 获取JSON数据
        data = request.get_json()
        results = data.get('results', [])
        
        if not results:
            return jsonify({'error': '没有结果可导出'}), 400
        
        # 创建Excel文件在内存中
        output = BytesIO()
        excel_handler.create_result_template(results, output)
        output.seek(0)
        
        # 发送文件
        return send_file(
            output,
            as_attachment=True,
            download_name='贸泽电子元件价格查询结果.xlsx',
            mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
        )
        
    except Exception as e:
        return jsonify({'error': f'导出文件时发生错误: {str(e)}'}), 500

@app.route('/download_template')
def download_template():
    try:
        # 创建Excel模板在内存中
        output = BytesIO()
        excel_handler.create_input_template(output)
        output.seek(0)
        
        # 发送文件
        return send_file(
            output,
            as_attachment=True,
            download_name='贸泽电子元件查询模板.xlsx',
            mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
        )
        
    except Exception as e:
        return jsonify({'error': f'下载模板时发生错误: {str(e)}'}), 500

if __name__ == '__main__':
    app.run(debug=True)